(function(){Meteor.methods({
  'newUser': function(data, roles){
    var userId;
    userId = Accounts.createUser({
      email:data.email, 
      password: data.password,
      profile: {
        name: data.name
      }
    });
    if(userId){
      Roles.addUsersToRoles(userId, roles);
      // Accounts.sendVerificationEmail(userId);
      return userId;
    };
  }
});

})();
