(function(){Meteor.publish("classOptions", function(){
  // if (Roles.userIsInRole(this.userId, ['administrator'])) {
      return className.find();
    // } else {
    //   this.stop();
    //   return;
    // }
});

Meteor.publish("subjectOptions", function(){
  // if (Roles.userIsInRole(this.userId, ['administrator'])) {
      return subjects.find();
    // } else {
    //   this.stop();
    //   return;
    // }
});

})();
