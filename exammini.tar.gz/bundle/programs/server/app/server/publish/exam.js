(function(){Meteor.publish("allExams", function(){
  return exams.find({belongsTo:this.userId});
})

Meteor.publish("allQuestions", function(token){
  return questions.find({belongsTo: this.userId, examId: token});
})

Meteor.publish("allClassNames", function(){
  if (Roles.userIsInRole(this.userId, ['Administrator'])) {
      return className.find({});
    } else {

      // user not authorized. do not publish secrets
      this.stop();
      return;

    }
})

Meteor.publish("allSubjects", function(){
  if (Roles.userIsInRole(this.userId, ['Administrator'])) {
      return subjects.find({});
    } else {

      // user not authorized. do not publish secrets
      this.stop();
      return;

    }
})

// Meteor.publish("getClassDetails", function(token){
//   if (Roles.userIsInRole(this.userId, ['Administrator'])) {
//       return className.find({_id: token});
//     } else {
//       // user not authorized. do not publish secrets
//       this.stop();
//       return;
//     }
// })


// Meteor.publish("getSubjectDetails", function(token){
//   if (Roles.userIsInRole(this.userId, ['Administrator'])) {
//       return subjects.find({_id: token});
//     } else {
//       // user not authorized. do not publish secrets
//       this.stop();
//       return;
//     }
// })




Meteor.publish("editQuestion", function(token){
  return questions.find({_id: token, belongsTo: this.userId});
})

})();
