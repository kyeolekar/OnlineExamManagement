(function(){// Accounts.config ({
//   sendVerificationEmail: true
// });

Meteor.startup(function(){
  // process.env.MAIL_URL="smtp://krishna@tutamail.com:yvabSIPmtDXZcWr1FlArGw@smtp.mandrillapp.com:587/";
});

})();
