(function(){// questions.permit(['insert']).ifLoggedIn().apply();
// answers.permit(['insert']).ifLoggedIn().apply();

})();
