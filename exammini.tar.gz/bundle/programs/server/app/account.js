(function(){Accounts.config ({
  forbidClientAccountCreation : true
  // sendVerificationEmail: true
});

})();
