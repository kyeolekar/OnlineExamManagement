(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['linto:jquery-ui'] = {};

})();

//# sourceMappingURL=linto_jquery-ui.js.map
