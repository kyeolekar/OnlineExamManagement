(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['mrt:flash-messages'] = {};

})();

//# sourceMappingURL=mrt_flash-messages.js.map
